<div class="secslider">
    <img name="slider" id="slider" width="100%" src="img/slider1.jpg">

</div>

