
    <footer>    
      <div class="bg-secondary text-white">
        <br>
        <div class="row vertical-divider">
          
          <div class="col-sm-4 text-black">
            <h4>Alfaroleiros Academia</h4>
            <p>15177 Oleiros</p>
            <p>A Coruña</p>
            <p>Tfno: 981 100 100</p>

            
          </div>
          <div class="col-sm-4" id="columnaMedio">
            <a href="#">SiteMap</a>
            <a href="#">Aviso legal</a>
            <a href="#">Sobre las Cookies</a>
            <a href="#">Política de Privacidad</a>

          </div>

            <div class="col-sm-4 text-black">
              <div class="rrss"><a href="http://www.instagram.com"><img src="img/logotipo-circular-de-instagran.png" width="30px" height="30px" alt="logotipo de instagram" target="_blank"><a></div>
              <div class="rrss"><a href="http://www.facebook.com"><img src="img/logotipo-circular-de-facebook.png" width="30px" height="30px" alt="logotipo de facebook" target="_blank"><a></div>
              <div class="rrss"><a href="http://www.twitter.com"><img src="img/logotipo-circular-de-twitter.png" width="30px" height="30px" alt="logotipo de twitter" target="_blank"><a></div>

 
            </div>        
          
        </div> 
        <br>
        

      </div>   


      <div class="bg-black text-white" id="barraFooter">
          <div class="col-sm-6">
            <small>&nbsp&nbsp&nbsp &#9400 Rafael Chamorro. Todos los derechos reservados.</small>
         </div>
          
           


      </div> 
    </footer>