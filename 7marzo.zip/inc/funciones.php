<?php


$hn = 'localhost';
$db= 'alfaroleiros';
$un= 'root';
$pw= '';
//$un= 'rafa';
//$pw= 'password';




?>